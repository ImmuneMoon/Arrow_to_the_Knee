import os
import shutil
import platform
import zipfile

def copy_files(src, dest):
    if not os.path.exists(dest):
        os.makedirs(dest)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dest, item)
        if os.path.isdir(s):
            shutil.copytree(s, d, False, None)
        else:
            shutil.copy2(s, d)

def extract_zip(src, dest):
    with zipfile.ZipFile(src, 'r') as zip_ref:
        zip_ref.extractall(dest)

def update_scripts():
    # Check if update is needed
    update_needed = input("Do you want to update the scripts? (y/n): ").lower()
    if update_needed == 'y':
        # Define source and destination directories
        source_scripts = os.path.join("scripts", "skyrim_LE")
        destination_scripts = os.path.join(install_dir, "Scripts")
        
        source_zip = os.path.join("Data", "Scripts", "Source.zip")
        destination_source = os.path.join(install_dir, "Scripts", "Source")
        
        # Copy compiled scripts to Skyrim's directory
        copy_files(source_scripts, destination_scripts)

        # Extract source zip to Skyrim's directory
        extract_zip(source_zip, destination_source)
        
        print("Scripts updated successfully!")
    else:
        print("Skipping script update.")

def main():
    # Prompt user for install directory
    global install_dir
    install_dir = input("Please enter your Skyrim install directory (default: C:\\Program Files (x86)\\Steam\\steamapps\\common\\Skyrim): ")
    if not install_dir:
        install_dir = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Skyrim"
    
    # Define additional source and destination directories
    source_esp = os.path.join("Data", "EldenRingArrowInTheKnee.esp")
    destination_esp = os.path.join(install_dir, "EldenRingArrowInTheKnee.esp")
    
    source_config = os.path.join("Data", "config.txt")
    destination_config = os.path.join(install_dir, "config.txt")
    
    source_music = os.path.join("audio")
    destination_music = os.path.join(install_dir, "Music", "YourMod")

    # Copy ESP file to Skyrim's directory
    shutil.copy2(source_esp, destination_esp)
    
    # Copy config file to Skyrim's directory
    shutil.copy2(source_config, destination_config)
    
    # Copy music files to Skyrim's Music directory
    copy_files(source_music, destination_music)

    # Update scripts if needed
    update_scripts()
    
    print("Setup completed successfully!")

if __name__ == "__main__":
    main()
