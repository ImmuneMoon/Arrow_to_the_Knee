# Arrow to The Knee Installation Instructions

1. **Download and Install Prerequisites**:
   - Install SKSE from [skse.silverlock.org](http://skse.silverlock.org).
   - Install Lua from [lua.org](https://www.lua.org).
   - Ensure Python is installed on your system.

2. **Run the Setup Script**:
   - Open a terminal or command prompt.
   - Navigate to the project directory.
   - Run the setup script using the following command:

     ```bash
     python setup.py
     ```

3. **Activate the Mod**:
   - Use your mod manager to activate `EldenRingArrowInTheKnee.esp`.

## Additional Notes

- Ensure the `config.txt` file is correctly formatted and placed in the `Data` folder.
- Double-check paths and configurations to ensure they match your system setup.

## Requirements

- Skyrim Legendary Edition (LE)
- SKSE (Skyrim Script Extender)
- Lua (required to run the Lua scripts)
- Python (needed to run the setup script)

Enjoy your adventure in the Elden Ring x Skyrim crossover world!
