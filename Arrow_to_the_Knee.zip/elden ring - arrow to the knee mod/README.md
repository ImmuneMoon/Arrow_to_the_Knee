# Arrow to The Knee

## Overview

This mod is a fun crossover between Elden Ring and Skyrim, where getting hit with an arrow to the knee teleports you to Skyrim until you beat the main quest. It includes scripts to track the completion of the Skyrim main quest, manage saves, and handle transitions between games.

## Features

- **Main Quest Tracking**: Tracks the completion of the Skyrim main quest and sets a global variable.
- **Save Management**: Manages save files and integrates with the Lua script for additional functionality.
- **Configuration File**: Allows customization of various settings via `config.txt`.
- **Audio Integration**: Includes custom audio files for a richer experience.
- **Convenient Launch**: Includes a batch file to launch Skyrim with SKSE.
- **Auto-Update**: Prompts the user for an install directory and offers to auto-update scripts.

## Requirements

- **Skyrim Legendary Edition (LE)**
- **SKSE (Skyrim Script Extender)**
- **Lua**: Required to run the Lua scripts.
- **Python**: Needed to run the setup script.

## Installation

1. **Download and Install Prerequisites**:
   - Install SKSE from [skse.silverlock.org](http://skse.silverlock.org).
   - Install Lua from [lua.org](https://www.lua.org).
   - Ensure Python is installed on your system.

2. **Run the Setup Script**:
   - Open a terminal or command prompt.
   - Navigate to the project directory.
   - Run the setup script using the following command:

     ```bash
     python setup.py
     ```

   - When prompted, enter your Skyrim install directory or press Enter to use the default directory.
   - When prompted, choose whether to update the scripts.

3. **Activate the Mod**:
   - Use your mod manager to activate `EldenRingArrowInTheKnee.esp`.

4. **Launch the Game**:
   - Use the `skyrim_launcher.bat` file included in the `scripts` folder to launch the game.

     ```bash
     scripts\skyrim_launcher.bat
     ```

## Usage

- **Mod Activation**: Ensure the mod is activated in your mod manager.
- **Save Management**: The Lua script will manage save files and check the completion of the Skyrim main quest.
- **Gameplay**: Enjoy the crossover features and have fun!

## Troubleshooting

- **Script Compilation Issues**: Ensure all scripts are in the correct folder.
- **Configuration Errors**: Double-check the `config.txt` file for any typos or incorrect paths.

## Credits

- **Developed by**: [ImmuneMoon]
- **Special Thanks**: To the Skyrim and Elden Ring communities for their support and inspiration.

## License

This mod is provided as-is and is free to use for non-commercial purposes. Please credit the original author if you distribute this mod.
